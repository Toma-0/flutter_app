<?php
/**
 * [API]ターミナル上でコマンドを実行するクラス
 * 
 * @author KISHI Noriki <g1744366@cc.kyoto-su.ac.jp>
 * @copylight KISHI Noriki All Right Reserved
 */
class Terminal {
    /**
     * コンストラクタ
     */
    public function __construct() {}

    /**
     * コマンドを実行する
     * @param string $a_command コマンド名
     * @param string $arguments コマンドのオプション群。単体なら内部で配列にキャスト、複数なら可変長引数として受け取る。
     * @return array
     */
    public function exec($a_command, $arguments) {
        if (gettype($arguments) == 'string') {
            // echo '文字列だす';
            $arguments = array($arguments);
        }
        $separeted_options = '"';
        $separeted_options .= implode(" ", $arguments);
        $separeted_options .= '"';
        $separeted_command = implode(" ", [$a_command, $separeted_options]);
        exec($separeted_command, $output);
        return $output;
    }
}
?>