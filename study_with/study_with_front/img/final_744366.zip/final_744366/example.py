import MeCab
import sys

class Example:
    """
    例題クラス。形態素解析を行う。
    """
    def __init__(self):
        """
        コンストラクタ
        """
        self.strings = ''
        return

    def __str__(self):
        """
        自身を文字列として返す。
        """
        return ', '.join(self.strings)

    def parse(self, a_string):
        """
        与えられた文字列を解析した結果をスペース区切りにする。
        """
        if a_string[0] == '"': a_string = a_string[1:]
        if a_string[:-1] == '"': a_string = a_string[:-1]
        a_mecab = MeCab.Tagger("-Ochasen")
        another_string = a_mecab.parse(a_string)
        lines = another_string.split('\n')
        result = []
        for line in lines:
            feature = line.split('\t')
            if len(feature) > 3:
                hinshi = feature[3].split('-')[0]
                if hinshi in ('名詞', '動詞'):
                    result.append(feature[0])
        self.strings = result
        return

if __name__ == '__main__':
    args = sys.argv[1:] # スクリプト名以後の引数を取得
    argument = ''.join(args) # 引数の結合
    example = Example() # 例題クラスの呼び出し
    example.parse(argument) # 解析
    print(example) # 出力