<?php

require_once('./simple_html_dom.php');
require_once('./Terminal.php');
/**
 * [API]最終課題を行うクラス
 * 
 * [学籍番号] 744366
 * [氏名] 岸 典樹
 * [最終更新日] 2021.2.1
 * [課題1] 良好
 * [課題2] 良好
 * [課題3] 良好
 * [課題4] 良好
 * [課題5] 良好
 * [課題6] 未実装
 * 
 * [入力URL1] https://docs.oracle.com/javase/jp/8/docs/api/java/util/ArrayList.html (210行目)
 * [入力URL2] https://docs.oracle.com/javase/jp/8/docs/api/java/lang/Integer.html (211行目)
 * [入力URL3] http://www.kyoto-su.ac.jp (212行目)
 * 
 * @author KISHI Noriki <g1744366@cc.kyoto-su.ac.jp>
 * @copylight KISHI Noriki All Right Reserved
 */
class Example {
	private array $argv; // コマンドライン引数
	private string $url; // 解析元のURL
	private array $a_list; // 単語リスト
	private $a_database; // データベース

	/**
	 * コンストラクタ
	 * @param string $a_url 調査するURL
	 * @param array $argv コマンドライン引数
	 */
	public function __construct(string $a_url, array $argv) {
		$this->argv = $argv;
		array_shift($this->argv);
		$this->url = $a_url;
		$this->a_list = array();
		$the_current_sql_filename = './test.sqlite3';
		$this->init_sqlfile($the_current_sql_filename);
		return;
	}

	/**
	 * 配列内に、マッチするデータがあるか比較する
	 * @param array $an_array 探されるワード
	 * @param array $another_array 探すワード
	 * @return bool $an_arrayに$another_arrayの中でマッチする要素が1つでもあればtrueを返す
	 */
	private function array_match($an_array, $another_array) {
		$is_find = false;
		foreach($an_array as $an_element) {
			if(array_search($an_element, $another_array) != false) {
				$is_find = true;
			}
		}
		return $is_find;
	}
	
	/**
	 * URLドキュメントを出力する。(課題1)
	 */
	public function print_url_document() {
		$this->print("URL", "$this->url");
		return;
	}
	
	/**
	 * 出現回数の高い単語トップNを取得する(課題2)
	 */
	public function get_frequently_appear_words(&$response, $number_of_limit) {
		// htmlタグを外す.
		$a_string = $this->get_sentences_as_words();
		// PHP MeCabがインストールできない(おそらくBigSurが原因)ため、自前のPHPスクリプト + Pythonスクリプトを使用
		$terminal = new Terminal();
		$another_string = preg_replace('/\s+/', '', $a_string);
		$ll = $terminal->exec('python example.py', $another_string );
		foreach($ll as $a_line) {
			$this->a_list = array_merge($this->a_list, explode(', ', $a_line));
		}
		// ここからDBへ格納していく
		foreach($this->a_list as $a_string) {
			$a_statement = $this->a_database->prepare("INSERT INTO dictionary (word, url) VALUES (:word, :url)");
			$a_statement->bindValue(':word', $a_string, SQLITE3_TEXT);
			$a_statement->bindValue(':url', $this->url, SQLITE3_TEXT);
			$result_flag = $a_statement->execute();
		}
		// 格納が終わったら select word from dictionary limit 10 orderby cnt desc する(要するにリミット10で頻度が高いものを抽出)
		$another_statement = $this->a_database->prepare("SELECT *, COUNT(*) as number_of_appearances FROM dictionary GROUP BY word ORDER BY number_of_appearances DESC LIMIT :limit");
		$another_statement->bindValue(':limit', $number_of_limit, SQLITE3_INTEGER);
		$result = $another_statement->execute();
		$response = array();
		if($result !== false) {
			while($an_array = $result->fetchArray()) {
				array_push($response, $an_array);
			}
		}
	}

	/**
	 * 総単語数を取得
	 * @return integer
	 */
	public function get_number_of_words() {
		$result = $this->a_database->querySingle("SELECT COUNT(*) FROM dictionary");
		return $result;
	}
	
	/**
	 * 文字列を単語群として取得する
	 */
	public function get_sentences_as_words() {
		$a_string = $this->get_text_from_html();
		return $a_string;
	}

	/**
	 * URLが指すHTMLファイルからテキスト情報を抽出
	 */
	public function get_text_from_html() {
		$a_html = file_get_html($this->url);
		return strip_tags($a_html);
	}

	/**
	 * SQLiteのファイルの初期化
	 * @param string $a_filename SQLのファイル名(相対パスを想定)
	*/
	public function init_sqlfile($a_filename) {
		if( count($this->argv) > 0) {
			if($this->array_match($this->argv, ['-i', '--init'] )) {
				// 引数が1以上あり、-iまたは--initが設定されていればデータベースの初期化をおこなう
				if(file_exists($a_filename)) {
					$this->print('ファイルは既にあるので初期化します');
					(new Terminal)->exec("rm -rf", $a_filename);
				}
				$this->a_database = new SQLite3('./test.sqlite3');
				$this->a_database->prepare("CREATE TABLE dictionary (word TEXT, url TEXT)")->execute();
				// else{
				// 	$this->print('ファイルがないので新規生成します');
				// }
			}
		}
		$this->a_database = new SQLite3('./test.sqlite3');
	}
	
	/**
	 * オーバーライドしたprint関数
	 * @param string... $strings 出力したい文字列(可変超引数)
	 */
	public function print(...$strings) {
		foreach($strings as $index => $a_string) {
			print($a_string);
			if(count($strings) - 1 > $index) {
				print("\t");
			}else{
				print("\n");
			}
		}
	}

	/**
	 * df値を取得
	 */
	public function set_df(&$df_list, $an_array) {
		$number_of_words = $this->get_number_of_words();
		$another_array = array();
		foreach($an_array as $a_column) {
			// word単位でcount(url)した結果を使う
			$a_word = $a_column["word"];
			$count_of_documents = $this->a_database->querySingle("SELECT COUNT(url) FROM dictionary WHERE word='$a_word'");
			$idf = $count_of_documents / $this->get_number_of_words();
			$a_column["idf"] = $idf;
			$a_column["df"] = log($idf);
			array_push($another_array, $a_column);
		}
		$df_list = $another_array;
	}

	/**
	 * tf値を取得
	 */
	public function set_tf(&$tf_list, &$an_array) {
		$number_of_words = $this->get_number_of_words();
		$another_array = array();
		foreach ($an_array as $index => $value) {
			$tf = $value["number_of_appearances"] / $number_of_words;
			$value["tf"] = $tf;
			array_push($another_array, $value);
		}
		$tf_list = $another_array;
	}

	/**
	 * tfidf値を取得
	 */
	public function set_tfidf(&$tfidf_list, &$an_array) {
		$another_array = array();
		foreach ($an_array as $index => $value) {
			$tfidf = $value["tf"] * $value["idf"];
			$value["tfidf"] = $tfidf;
			array_push($another_array, $value);
		}
		$tfidf_list = $another_array;
	}
}

// $example = new Example('https://docs.oracle.com/javase/jp/8/docs/api/java/util/ArrayList.html', $argv);
// $example = new Example('https://docs.oracle.com/javase/jp/8/docs/api/java/lang/Integer.html', $argv);
$example = new Example('http://www.kyoto-su.ac.jp', $argv);

// question1
$example->print("=====< 課題1 >=====");
$example->print_url_document();
echo "\n";


// question2
$example->print("=====< 課題2 >=====");
$example->get_frequently_appear_words($popular_words, 10);
$example->print("単語", "URL", "出現回数");
$example->print();
foreach($popular_words as $a_column) {
	$example->print($a_column["word"], $a_column["url"], $a_column["number_of_appearances"]);
}
echo "\n";


// question3
$example->print("=====< 課題3 >=====");
$example->set_tf($tf_list, $popular_words);
$example->print("単語", "tf値");
$example->print();
foreach($tf_list as $a_tf) {
	$example->print($a_tf["word"], $a_tf["tf"]);
}
echo "\n";

// question4
$example->print("=====< 課題4 >=====");
$example->set_df($df_list, $tf_list);
$example->print("単語", "df値", "idf値");
$example->print();
foreach($df_list as $a_df) {
	$example->print($a_df["word"], $a_df["df"], $a_df["idf"]);
}
echo "\n";

// question5
$example->print("=====< 課題5 >=====");
$example->set_tfidf($tfidf_list, $df_list);
$example->print("単語", "tfidf値");
$example->print();
foreach($tfidf_list as $a_tfidf) {
	$example->print($a_tfidf["word"], $a_tfidf["tfidf"]);
}
echo "\n";

// question6
$example->print("=====< 課題6 >=====");

echo "\n";

$example->print("system.exit"); // exit.
?>