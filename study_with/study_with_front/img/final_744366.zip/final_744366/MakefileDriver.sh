#! /bin/bash
# -*- coding: utf-8 -*-
ROOT=`pwd`
TARGET='final_744366'

if [ $1 = 'zip' ]
then
	# make zipが実行された時の処理
	# 一階層上に自身を圧縮したファイルを作成
	cd ../;
	zip -r ${TARGET}.zip ${TARGET}/
fi
